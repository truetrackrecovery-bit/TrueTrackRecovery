import { ShieldCheck, ArrowRight, Lock, Globe, Zap } from "lucide-react";
import Logo from "./Logo";

export default function Hero() {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-navy-950 via-navy-900 to-[#0f3460]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(26,95,158,0.15),transparent_60%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(212,160,23,0.06),transparent_60%)]" />

      {/* Grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left */}
          <div className="animate-fade-in-up">
            <div className="inline-flex items-center gap-2 bg-[#1a5f9e]/20 border border-[#1a5f9e]/40 rounded-full px-4 py-1.5 mb-6">
              <ShieldCheck className="w-4 h-4 text-gold-400" />
              <span className="text-blue-200 text-sm font-medium">
                Case Intake Open — Respond Within 24 Hours
              </span>
            </div>

            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.1] mb-6">
              You Were Targeted.{" "}
              <span className="text-gold-400">We Find the Trail.</span>
            </h1>

            <p className="text-blue-200 text-lg lg:text-xl leading-relaxed mb-6 max-w-xl">
              Our specialists conduct structured case reviews, trace digital
              evidence, and outline your available recovery options —{" "}
              <strong className="text-white">at no cost to you upfront.</strong>
            </p>

            <p className="text-navy-300 text-base leading-relaxed mb-8 max-w-xl">
              Lost access to your account? Forgotten your password? We help you
              know exactly what the next step is — whether it's crypto recovery,
              account access, or tracing stolen assets.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <button
                onClick={() => scrollTo("#case-review")}
                className="group inline-flex items-center justify-center gap-2 px-8 py-4 bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-base rounded-xl transition-all hover:shadow-xl hover:shadow-gold-500/25 animate-pulse-gold"
              >
                Submit Your Case
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => scrollTo("#how-it-works")}
                className="inline-flex items-center justify-center gap-2 px-8 py-4 border-2 border-navy-500 hover:border-blue-400 text-white font-semibold text-base rounded-xl transition-all hover:bg-navy-800/50"
              >
                See How It Works
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 text-sm text-blue-200">
              {[
                { icon: Lock, label: "100% Confidential" },
                { icon: Globe, label: "International Cases" },
                { icon: Zap, label: "Response Within 24h" },
              ].map((item) => (
                <span key={item.label} className="flex items-center gap-1.5">
                  <item.icon className="w-4 h-4 text-gold-500 flex-shrink-0" />
                  {item.label}
                </span>
              ))}
            </div>
          </div>

          {/* Right – trust card */}
          <div className="animate-fade-in-up stagger-3 hidden lg:block">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-[#1a5f9e]/20 to-gold-500/10 rounded-3xl blur-2xl" />
              <div className="relative bg-navy-800/60 backdrop-blur-sm border border-navy-700/50 rounded-2xl p-8 space-y-6">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 bg-[#1a5f9e]/20 rounded-xl flex items-center justify-center">
                    <Logo size={36} showText={false} />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">
                      Free Fraud Case Review
                    </h3>
                    <p className="text-blue-300 text-sm">
                      No commitment. No upfront fees.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6 pt-4 border-t border-navy-700">
                  {[
                    { value: "48h", label: "Average Review Time" },
                    { value: "100%", label: "Confidential Process" },
                    { value: "$0", label: "Cost to Start" },
                    { value: "12+", label: "Fraud Categories" },
                  ].map((stat) => (
                    <div key={stat.label}>
                      <div className="text-gold-400 font-heading text-3xl font-bold">
                        {stat.value}
                      </div>
                      <div className="text-blue-300 text-sm mt-1">
                        {stat.label}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-navy-700 pt-5">
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2">
                      {[
                        "bg-[#1a5f9e]",
                        "bg-gold-500",
                        "bg-[#0f3460]",
                        "bg-gold-600",
                      ].map((bg, i) => (
                        <div
                          key={i}
                          className={`w-9 h-9 rounded-full ${bg} border-2 border-navy-800 flex items-center justify-center text-[10px] font-bold text-white`}
                        >
                          {["DM", "AK", "RO", "TB"][i]}
                        </div>
                      ))}
                    </div>
                    <div className="text-blue-200 text-sm">
                      <strong className="text-white">★★★★★</strong>{" "}
                      trusted worldwide
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
