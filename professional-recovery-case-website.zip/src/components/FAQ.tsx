import { useState } from "react";
import { ChevronDown, ArrowRight } from "lucide-react";

const faqs = [
  {
    q: "What types of cases do you review?",
    a: "We review a wide range of financial fraud cases, including cryptocurrency scams, investment fraud, forex trading scams, romance scams, online trading fraud, impersonation scams, and other types of financial fraud. If you've lost money to any form of scam, we encourage you to submit your case for review.",
  },
  {
    q: "How long does a review take?",
    a: "Initial case assessments are typically completed within 24–48 hours of receiving your submission. More complex cases involving multiple transactions or jurisdictions may require additional time. We'll keep you informed of our progress throughout the review process.",
  },
  {
    q: "Is my information confidential?",
    a: "Absolutely. We take data privacy extremely seriously. All information you provide is encrypted, stored securely, and accessible only to the analyst assigned to your case. We never share your personal details with third parties without your explicit consent.",
  },
  {
    q: "Do you guarantee recovery?",
    a: "While we cannot guarantee recovery in every case, we provide honest, thorough assessments of your situation and the most viable recovery options available. Our team uses advanced tools and methodologies to maximize the chances of a positive outcome.",
  },
  {
    q: "What documents should I provide?",
    a: "To help us assess your case effectively, please provide any relevant documentation including transaction receipts, screenshots of communications with the scammer, wallet addresses, bank statements, emails, and any other evidence related to the fraudulent activity. The more information you provide, the better we can evaluate your case.",
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-widest mb-3">
            FAQ
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-navy-500 text-lg">
            Find answers to common questions about our recovery case review
            process.
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3 mb-14">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={i}
                className={`border rounded-xl transition-all duration-200 ${
                  isOpen
                    ? "border-gold-300 bg-gold-50/30 shadow-sm"
                    : "border-navy-100 bg-white hover:border-navy-200"
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex items-center justify-between w-full text-left px-6 py-5"
                  aria-expanded={isOpen}
                >
                  <span className="text-navy-900 font-semibold pr-4">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-navy-400 flex-shrink-0 transition-transform duration-200 ${
                      isOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-5 animate-slide-down">
                    <p className="text-navy-500 leading-relaxed">{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="text-center">
          <p className="text-navy-500 mb-4">
            Still have questions? Submit your case and our team will be happy to
            help.
          </p>
          <button
            onClick={() => scrollTo("#case-review")}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-navy-900 hover:bg-navy-800 text-white font-semibold rounded-xl transition-all hover:shadow-lg"
          >
            Start Your Case Review
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
