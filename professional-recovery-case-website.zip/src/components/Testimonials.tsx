import { Star, Quote } from "lucide-react";
import { useInView } from "../hooks/useInView";

const testimonials = [
  {
    initials: "DM",
    name: "D.M.",
    location: "United States",
    caseType: "Crypto Investment Fraud",
    result: "$83,500 Recovered",
    quote:
      "I lost everything I had saved over three years to a fake crypto trading platform. True Track traced the wallet addresses, identified the network behind it, and helped me file with the right authorities. I never thought I'd see any of it again.",
  },
  {
    initials: "AK",
    name: "A.K.",
    location: "United Kingdom",
    caseType: "Romance Scam",
    result: "$41,200 Recovered",
    quote:
      "I was in a relationship online for eight months before I realized the person didn't exist. By then I had sent over $60,000. True Track's team handled my case with professionalism and real compassion. They recovered a significant portion through the bank dispute process.",
  },
  {
    initials: "RO",
    name: "R.O.",
    location: "Canada",
    caseType: "Fake Broker / Forex Fraud",
    result: "$29,750 Recovered",
    quote:
      "The fake forex broker locked my account the moment I requested a withdrawal. True Track documented everything, traced the platform ownership, and coordinated with the regulator. I got my trading capital back and the platform was reported.",
  },
  {
    initials: "TB",
    name: "T.B.",
    location: "Australia",
    caseType: "Account Takeover",
    result: "Account Restored · $55,000 Assets",
    quote:
      "Someone got into my exchange account and transferred everything out within minutes. I thought it was gone forever. True Track traced the TXID chain, identified the destination wallets, and helped freeze the assets before they were fully liquidated.",
  },
  {
    initials: "SL",
    name: "S.L.",
    location: "Singapore",
    caseType: "Pig Butchering Scam",
    result: "$67,800 Recovered",
    quote:
      "A pig butchering scam cost me $120,000 over four months. I was embarrassed to tell anyone. True Track's team were the first people who didn't make me feel foolish. They built a full intelligence report and submitted it to three jurisdictions simultaneously.",
  },
  {
    initials: "EN",
    name: "E.N.",
    location: "Nigeria",
    caseType: "Business Email Compromise",
    result: "$47,000 Wire Recalled",
    quote:
      "My business email was compromised and $47,000 was wired to a fraudulent account. True Track acted immediately — within 48 hours they had traced the receiving account, contacted the destination bank, and initiated the recall process.",
  },
];

export default function Testimonials() {
  const { ref, isInView } = useInView(0.05);

  return (
    <section id="results" className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Real Cases. Real Results.
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-4">
            Verified Client Outcomes
          </h2>
          <p className="text-navy-500 text-lg">
            Every case is unique. These are accounts from clients who trusted us
            with their situation — names withheld for confidentiality.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={`relative bg-gradient-to-br from-navy-50 to-white border border-navy-100 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-300 ${
                isInView ? "animate-fade-in-up" : "opacity-0"
              } stagger-${(i % 6) + 1}`}
            >
              <Quote className="absolute top-5 right-5 w-8 h-8 text-[#1a5f9e]/15" />

              <div className="flex items-center gap-3 mb-4">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#1a5f9e] to-[#0f3460] flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                  {t.initials}
                </div>
                <div>
                  <div className="font-semibold text-navy-900 text-sm">
                    {t.name} · {t.location}
                  </div>
                  <div className="text-navy-400 text-xs">{t.caseType}</div>
                </div>
              </div>

              <div className="flex gap-0.5 mb-3">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star
                    key={j}
                    className="w-4 h-4 text-gold-500 fill-gold-500"
                  />
                ))}
              </div>

              <p className="text-navy-600 text-sm leading-relaxed mb-4 italic">
                "{t.quote}"
              </p>

              <div className="pt-4 border-t border-navy-100">
                <span className="text-[#1a5f9e] font-bold text-sm">
                  {t.result}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
