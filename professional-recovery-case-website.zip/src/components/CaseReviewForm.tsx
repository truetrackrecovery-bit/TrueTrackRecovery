import { useState, type FormEvent } from "react";
import { Send, Loader2, CheckCircle, AlertCircle, Upload, ShieldCheck, Lock } from "lucide-react";

const FORMSPREE_URL = "https://formspree.io/f/xdavpdpa";

const scamTypes = [
  "Crypto Scam",
  "Investment Scam",
  "Forex Scam",
  "Romance Scam",
  "Online Fraud",
  "Pig Butchering Scam",
  "Business Email Compromise",
  "Fake Broker Platform",
  "Tech Support Scam",
  "NFT / Digital Asset Fraud",
  "Real Estate / Rental Fraud",
  "Wire Transfer Fraud",
  "Impersonation Scam",
  "Account Access / Password Lockout",
  "Other",
];

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  country: string;
  amountLost: string;
  incidentDate: string;
  scamType: string;
  platform: string;
  walletAddress: string;
  transactionHash: string;
  description: string;
  confirmation: boolean;
}

const initialFormData: FormData = {
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  country: "",
  amountLost: "",
  incidentDate: "",
  scamType: "",
  platform: "",
  walletAddress: "",
  transactionHash: "",
  description: "",
  confirmation: false,
};

export default function CaseReviewForm() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [files, setFiles] = useState<FileList | null>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const update = (field: keyof FormData, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!formData.confirmation) {
      setErrorMsg("Please confirm that the information provided is accurate.");
      setStatus("error");
      return;
    }
    setStatus("loading");
    setErrorMsg("");
    try {
      const body = new FormData();
      Object.entries(formData).forEach(([key, val]) => {
        if (key !== "confirmation") body.append(key, String(val));
      });
      body.append("fullName", `${formData.firstName} ${formData.lastName}`.trim());
      body.append("confirmation", formData.confirmation ? "Yes" : "No");
      if (files) Array.from(files).forEach((file) => body.append("attachment", file));

      const res = await fetch(FORMSPREE_URL, {
        method: "POST",
        body,
        headers: { Accept: "application/json" },
      });
      if (res.ok) {
        setStatus("success");
        setFormData(initialFormData);
        setFiles(null);
      } else {
        const data = await res.json();
        setErrorMsg(data?.errors?.map((e: { message: string }) => e.message).join(", ") || "Something went wrong. Please try again.");
        setStatus("error");
      }
    } catch {
      setErrorMsg("Network error. Please check your connection and try again.");
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <section id="case-review" className="py-20 lg:py-28 bg-navy-50">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl p-10 shadow-lg border border-navy-100 animate-fade-in-up">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="font-heading text-3xl text-navy-900 mb-4">Thank You — Your Case Has Been Received</h2>
            <p className="text-navy-500 text-lg leading-relaxed mb-4">
              Your recovery case review request has been received. A member of our team will review your information and contact you within 24–48 hours.
            </p>
            <p className="text-navy-400 text-sm leading-relaxed mb-6">
              All information is kept strictly confidential. We will never share your details with third parties without your consent.
            </p>
            <button onClick={() => setStatus("idle")} className="inline-flex items-center gap-2 px-6 py-3 bg-navy-900 hover:bg-navy-800 text-white font-semibold rounded-xl transition-colors">
              Submit Another Case
            </button>
          </div>
        </div>
      </section>
    );
  }

  const inputClass = "w-full px-4 py-3 bg-white border border-navy-200 rounded-xl text-navy-900 placeholder-navy-400 focus:outline-none focus:ring-2 focus:ring-[#1a5f9e] focus:border-transparent transition-all text-sm";
  const labelClass = "block text-sm font-medium text-navy-700 mb-1.5";

  return (
    <section id="case-review" className="py-20 lg:py-28 bg-navy-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-block text-[#1a5f9e] font-semibold text-sm uppercase tracking-widest mb-3">Free Case Review</span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-4">Submit Your Case. Get Clarity.</h2>
          <p className="text-navy-500 text-lg mb-4">
            Complete the form below for a free, confidential case review. A real specialist will review your details and contact you directly — at no cost to you upfront.
          </p>
          <div className="flex flex-wrap justify-center gap-x-5 gap-y-2 text-sm text-navy-500">
            <span className="flex items-center gap-1.5"><Lock className="w-4 h-4 text-[#1a5f9e]" />100% Confidential</span>
            <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-[#1a5f9e]" />Secure & Encrypted</span>
            <span className="flex items-center gap-1.5">⚡ Response Within 24 Hours</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-lg border border-navy-100 p-6 sm:p-8 lg:p-10 space-y-8">
          {/* Personal Info */}
          <div>
            <h3 className="text-navy-900 font-semibold text-lg mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#1a5f9e]" /> Personal Information
            </h3>
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="firstName" className={labelClass}>First Name <span className="text-red-500">*</span></label>
                <input id="firstName" type="text" required className={inputClass} placeholder="John" value={formData.firstName} onChange={(e) => update("firstName", e.target.value)} />
              </div>
              <div>
                <label htmlFor="lastName" className={labelClass}>Last Name <span className="text-red-500">*</span></label>
                <input id="lastName" type="text" required className={inputClass} placeholder="Doe" value={formData.lastName} onChange={(e) => update("lastName", e.target.value)} />
              </div>
              <div>
                <label htmlFor="email" className={labelClass}>Email Address <span className="text-red-500">*</span></label>
                <input id="email" type="email" required className={inputClass} placeholder="john@example.com" value={formData.email} onChange={(e) => update("email", e.target.value)} />
              </div>
              <div>
                <label htmlFor="phone" className={labelClass}>WhatsApp / Phone <span className="text-red-500">*</span></label>
                <input id="phone" type="tel" required className={inputClass} placeholder="+1 (555) 000-0000" value={formData.phone} onChange={(e) => update("phone", e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="country" className={labelClass}>Country <span className="text-red-500">*</span></label>
                <input id="country" type="text" required className={inputClass} placeholder="United States" value={formData.country} onChange={(e) => update("country", e.target.value)} />
              </div>
            </div>
          </div>

          <hr className="border-navy-100" />

          {/* Case Details */}
          <div>
            <h3 className="text-navy-900 font-semibold text-lg mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#1a5f9e]" /> Case Details
            </h3>
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="amountLost" className={labelClass}>Approximate Amount Lost (USD) <span className="text-red-500">*</span></label>
                <input id="amountLost" type="text" required className={inputClass} placeholder="$10,000" value={formData.amountLost} onChange={(e) => update("amountLost", e.target.value)} />
              </div>
              <div>
                <label htmlFor="incidentDate" className={labelClass}>Date of Incident <span className="text-red-500">*</span></label>
                <input id="incidentDate" type="date" required className={inputClass} value={formData.incidentDate} onChange={(e) => update("incidentDate", e.target.value)} />
              </div>
              <div>
                <label htmlFor="scamType" className={labelClass}>Type of Fraud Experienced <span className="text-red-500">*</span></label>
                <select id="scamType" required className={inputClass} value={formData.scamType} onChange={(e) => update("scamType", e.target.value)}>
                  <option value="">Select type</option>
                  {scamTypes.map((t) => (<option key={t} value={t}>{t}</option>))}
                </select>
              </div>
              <div>
                <label htmlFor="platform" className={labelClass}>Platform Used <span className="text-red-500">*</span></label>
                <input id="platform" type="text" required className={inputClass} placeholder="e.g., Binance, MetaTrader, Coinbase" value={formData.platform} onChange={(e) => update("platform", e.target.value)} />
              </div>
              <div>
                <label htmlFor="walletAddress" className={labelClass}>Wallet Address <span className="text-navy-400 font-normal">(if applicable)</span></label>
                <input id="walletAddress" type="text" className={inputClass} placeholder="0x..." value={formData.walletAddress} onChange={(e) => update("walletAddress", e.target.value)} />
              </div>
              <div>
                <label htmlFor="transactionHash" className={labelClass}>Transaction Hash / TXID <span className="text-navy-400 font-normal">(if applicable)</span></label>
                <input id="transactionHash" type="text" className={inputClass} placeholder="0x..." value={formData.transactionHash} onChange={(e) => update("transactionHash", e.target.value)} />
              </div>
            </div>
          </div>

          <hr className="border-navy-100" />

          {/* Description */}
          <div>
            <label htmlFor="description" className={labelClass}>Brief Summary of What Happened <span className="text-red-500">*</span></label>
            <textarea id="description" required rows={5} className={inputClass + " resize-none"}
              placeholder="Please describe what happened, how you were contacted, amounts sent, and any other details relevant to your case. The more information you provide, the better we can assess your options."
              value={formData.description} onChange={(e) => update("description", e.target.value)} />
          </div>

          {/* File upload */}
          <div>
            <label className={labelClass}>Upload Supporting Evidence <span className="text-navy-400 font-normal">(screenshots, PDFs, images — optional but recommended)</span></label>
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-navy-200 rounded-xl cursor-pointer hover:border-[#1a5f9e] hover:bg-[#1a5f9e]/5 transition-all">
              <Upload className="w-8 h-8 text-navy-400 mb-2" />
              <span className="text-sm text-navy-500">{files && files.length > 0 ? `${files.length} file(s) selected` : "Click to upload or drag & drop"}</span>
              <span className="text-xs text-navy-400 mt-1">PNG, JPG, PDF up to 10MB per file</span>
              <input type="file" className="hidden" multiple accept=".png,.jpg,.jpeg,.pdf,.gif,.webp" onChange={(e) => setFiles(e.target.files)} />
            </label>
          </div>

          {/* Confirmation */}
          <div className="flex items-start gap-3">
            <input id="confirmation" type="checkbox" required checked={formData.confirmation}
              onChange={(e) => update("confirmation", e.target.checked)}
              className="mt-1 w-5 h-5 rounded border-navy-300 text-[#1a5f9e] focus:ring-[#1a5f9e] accent-[#1a5f9e]" />
            <label htmlFor="confirmation" className="text-sm text-navy-600">
              I confirm that the information provided is accurate and I consent to True Track Recovery processing my data for the purpose of case assessment. I understand there is no obligation and no upfront cost.
            </label>
          </div>

          {status === "error" && errorMsg && (
            <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm animate-fade-in">
              <AlertCircle className="w-5 h-5 flex-shrink-0" /> {errorMsg}
            </div>
          )}

          <button type="submit" disabled={status === "loading"}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-4 bg-gold-500 hover:bg-gold-400 disabled:bg-gold-300 text-navy-950 font-bold text-base rounded-xl transition-all hover:shadow-lg hover:shadow-gold-500/25 disabled:cursor-not-allowed">
            {status === "loading" ? (<><Loader2 className="w-5 h-5 animate-spin" /> Submitting…</>) : (<><Send className="w-5 h-5" /> Submit Free Case Review</>)}
          </button>

          <p className="text-xs text-navy-400 text-center">
            By submitting, you agree to be contacted by a True Track Recovery specialist regarding your case. Your information is never shared with third parties.
          </p>
        </form>
      </div>
    </section>
  );
}
