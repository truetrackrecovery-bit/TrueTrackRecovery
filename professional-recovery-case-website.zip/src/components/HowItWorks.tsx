import { FileText, Search, Fingerprint, Lightbulb, ArrowRight } from "lucide-react";
import { useInView } from "../hooks/useInView";

const steps = [
  {
    icon: FileText,
    step: "Step 01",
    title: "Submit Your Case",
    desc: "Complete the confidential case review form. Provide details about what happened, amounts involved, and any evidence you have — including screenshots, transaction IDs, or account details.",
  },
  {
    icon: Search,
    step: "Step 02",
    title: "Specialist Review",
    desc: "Our team conducts a structured analysis — evaluating transaction records, platform details, account information, and recovery viability based on your specific situation.",
  },
  {
    icon: Fingerprint,
    step: "Step 03",
    title: "Intelligence Assessment",
    desc: "We apply OSINT and blockchain tracing methodologies to map available evidence pathways, identify bad actors where possible, and analyze the digital footprint of the fraud.",
  },
  {
    icon: Lightbulb,
    step: "Step 04",
    title: "Options Briefing",
    desc: "You receive a clear breakdown of your available options, recommended next steps, and a realistic assessment of your situation — so you know exactly what to do next.",
  },
];

export default function HowItWorks() {
  const { ref, isInView } = useInView(0.1);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="how-it-works" className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-[#1a5f9e] font-semibold text-sm uppercase tracking-widest mb-3">
            Our Process
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-4">
            How a Case Review Works
          </h2>
          <p className="text-navy-500 text-lg">
            A clear, structured process — from your first submission to a full
            case strategy briefing. Every step is explained so you know exactly
            where you stand.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-14">
          {steps.map((s, i) => (
            <div
              key={s.step}
              className={`relative text-center group ${
                isInView ? "animate-fade-in-up" : "opacity-0"
              } stagger-${i + 1}`}
            >
              <div className="relative mx-auto w-24 h-24 rounded-2xl bg-gradient-to-br from-[#1a5f9e] to-[#0f3460] flex items-center justify-center mb-5 shadow-lg group-hover:scale-105 transition-transform duration-300">
                <s.icon className="w-10 h-10 text-white" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-gold-500 rounded-full flex items-center justify-center text-sm font-bold text-navy-950 shadow">
                  {i + 1}
                </div>
              </div>

              <span className="text-gold-600 font-semibold text-xs uppercase tracking-widest">
                {s.step}
              </span>
              <h3 className="font-heading text-lg text-navy-900 mt-1 mb-2">
                {s.title}
              </h3>
              <p className="text-navy-500 text-sm leading-relaxed">
                {s.desc}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={() => scrollTo("#case-review")}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-navy-900 hover:bg-[#0f3460] text-white font-semibold rounded-xl transition-all hover:shadow-lg"
          >
            Begin Your Free Case Review
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
