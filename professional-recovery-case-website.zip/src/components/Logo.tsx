interface LogoProps {
  size?: number;
  showText?: boolean;
  variant?: "dark" | "light";
}

export default function Logo({
  size = 48,
  showText = true,
  variant = "dark",
}: LogoProps) {
  const phoenixBlue = "#1a5f9e";
  const textBlack = "#000000";

  return (
    <div className="flex items-center gap-3">
      {/* Phoenix SVG */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 260"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0"
      >
        {/* Phoenix body */}
        <path
          d="M100 50 C90 80, 70 100, 60 130 C50 160, 55 200, 70 220 C65 200, 70 170, 85 150 C80 170, 85 200, 95 230 C90 210, 95 175, 105 150 C105 175, 110 210, 125 225 C115 195, 118 155, 130 130 C140 110, 145 90, 140 70 C135 85, 125 100, 115 110 C125 90, 130 70, 125 50 C115 65, 105 75, 100 80"
          fill={phoenixBlue}
        />
        {/* Head */}
        <ellipse cx="125" cy="70" rx="14" ry="18" fill={phoenixBlue} transform="rotate(-15 125 70)" />
        {/* Beak */}
        <path d="M136 62 L155 55 L138 68 Z" fill={phoenixBlue} />
        {/* Eye */}
        <circle cx="130" cy="65" r="2.5" fill="white" />
        {/* Wing feathers - main upward wing */}
        <path
          d="M100 85 C70 60, 40 40, 20 15 C35 40, 50 65, 75 85"
          fill={phoenixBlue}
          opacity="0.95"
        />
        <path
          d="M95 100 C65 70, 30 50, 8 30 C25 55, 45 75, 70 98"
          fill={phoenixBlue}
          opacity="0.85"
        />
        <path
          d="M92 115 C70 85, 35 65, 15 50 C30 70, 50 90, 75 113"
          fill={phoenixBlue}
          opacity="0.75"
        />
        <path
          d="M90 130 C75 100, 45 80, 28 68 C40 85, 60 105, 80 128"
          fill={phoenixBlue}
          opacity="0.65"
        />
        {/* Tail feathers */}
        <path
          d="M75 195 C55 200, 35 210, 20 225 C45 210, 65 200, 80 198"
          fill={phoenixBlue}
          opacity="0.8"
        />
        <path
          d="M80 205 C60 215, 40 225, 25 240 C50 225, 70 215, 85 208"
          fill={phoenixBlue}
          opacity="0.7"
        />
        {/* Claw */}
        <path d="M78 220 L73 240 M85 225 L88 248 M92 222 L98 242" stroke={phoenixBlue} strokeWidth="2.5" strokeLinecap="round" />
      </svg>

      {showText && (
        <div className="flex flex-col leading-none">
          <div className="font-heading flex items-baseline gap-1.5">
            <span
              className="text-xl sm:text-2xl font-bold tracking-tight"
              style={{ color: phoenixBlue }}
            >
              True
            </span>
            <span
              className="text-xl sm:text-2xl font-black tracking-tight"
              style={{ color: variant === "dark" ? textBlack : "#ffffff" }}
            >
              TRACK
            </span>
          </div>
          <div className="mt-1 flex items-center gap-1">
            <span
              className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em]"
              style={{ color: phoenixBlue }}
            >
              Recovery
            </span>
            <span style={{ color: phoenixBlue }} className="text-sm font-bold">
              .
            </span>
          </div>
          <div className="mt-0.5 h-0.5 bg-[#1a5f9e] w-full" />
        </div>
      )}
    </div>
  );
}
