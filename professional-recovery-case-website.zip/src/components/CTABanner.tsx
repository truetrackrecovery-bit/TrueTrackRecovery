import { ArrowRight, Shield } from "lucide-react";

export default function CTABanner() {
  const scrollTo = () => {
    const el = document.querySelector("#case-review");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="py-16 bg-gradient-to-r from-navy-900 via-navy-800 to-navy-900 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(212,160,23,0.06),transparent_70%)]" />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 mb-4">
          <Shield className="w-8 h-8 text-gold-400" />
        </div>
        <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl text-white mb-4">
          Don't Let Scammers Win.{" "}
          <span className="text-gold-400">Take Action Today.</span>
        </h2>
        <p className="text-navy-300 text-lg max-w-2xl mx-auto mb-8">
          Every day you wait reduces your chances of recovery. Submit your case
          now for a free, confidential assessment by our experienced team.
        </p>
        <button
          onClick={scrollTo}
          className="group inline-flex items-center gap-2 px-10 py-4 bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-base rounded-xl transition-all hover:shadow-xl hover:shadow-gold-500/25"
        >
          Start Your Free Case Review
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </section>
  );
}
