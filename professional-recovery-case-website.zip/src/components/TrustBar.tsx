import { ShieldCheck, Clock, Users, Award } from "lucide-react";

const items = [
  { icon: ShieldCheck, label: "100% Confidential" },
  { icon: Clock, label: "Response Within 24 Hours" },
  { icon: Users, label: "Specialist Analysts" },
  { icon: Award, label: "Trusted Worldwide" },
];

export default function TrustBar() {
  return (
    <section className="relative z-10 -mt-8 pb-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl border border-navy-100 p-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item) => (
            <div key={item.label} className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1a5f9e] to-[#0f3460] rounded-lg flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-gold-400" />
              </div>
              <span className="text-navy-800 font-medium text-sm">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
