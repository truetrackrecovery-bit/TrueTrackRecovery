import Logo from "./Logo";

export default function Footer() {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-navy-950 border-t border-navy-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <button onClick={() => scrollTo("#home")} className="mb-4" aria-label="True Track Recovery Home">
              <Logo size={40} variant="light" />
            </button>
            <p className="text-navy-400 text-sm leading-relaxed max-w-xs mt-4">
              Helping victims track, trace &amp; recover lost assets. Professional fraud investigation and case review services worldwide.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {[
                { label: "Home", href: "#home" },
                { label: "How It Works", href: "#how-it-works" },
                { label: "Services", href: "#services" },
                { label: "Case Results", href: "#results" },
                { label: "FAQ", href: "#faq" },
              ].map((l) => (
                <li key={l.href}>
                  <button onClick={() => scrollTo(l.href)} className="text-navy-400 hover:text-gold-400 text-sm transition-colors">
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-sm text-navy-400">
              <li>Crypto Fraud Recovery</li>
              <li>Account &amp; Password Recovery</li>
              <li>Investment Scam Recovery</li>
              <li>Wire Fraud Recall</li>
              <li>Romance Scam Assistance</li>
              <li>Asset Tracing &amp; OSINT</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-navy-400">
              <li>
                <a href="mailto:support@truetrackrecovery.com" className="hover:text-gold-400 transition-colors">
                  support@truetrackrecovery.com
                </a>
              </li>
              <li>Mon – Fri: 8AM – 8PM EST</li>
              <li>Emergency: 24/7 Available</li>
            </ul>
            <div className="flex gap-2 mt-4">
              <a href="https://facebook.com/truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                className="w-9 h-9 bg-navy-800 hover:bg-[#1877f2] text-navy-400 hover:text-white rounded-lg flex items-center justify-center transition-all">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>
              </a>
              <a href="https://instagram.com/truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                className="w-9 h-9 bg-navy-800 text-navy-400 hover:text-white rounded-lg flex items-center justify-center transition-all hover:bg-gradient-to-br hover:from-[#e1306c] hover:via-[#c13584] hover:to-[#833ab4]">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.849.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.849.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0z" /></svg>
              </a>
              <a href="https://tiktok.com/@truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="TikTok"
                className="w-9 h-9 bg-navy-800 hover:bg-black text-navy-400 hover:text-white rounded-lg flex items-center justify-center transition-all">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005.8 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1.84-.1z" /></svg>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-navy-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-navy-500 text-sm">
            &copy; {new Date().getFullYear()} True Track Recovery. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-navy-500">
            <button className="hover:text-gold-400 transition-colors">Privacy Policy</button>
            <button className="hover:text-gold-400 transition-colors">Terms of Service</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
