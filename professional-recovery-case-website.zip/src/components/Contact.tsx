import { useState, type FormEvent } from "react";
import { Mail, Clock, Send, Loader2, CheckCircle, AlertCircle, MapPin } from "lucide-react";

const FORMSPREE_URL = "https://formspree.io/f/xdavpdpa";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch(FORMSPREE_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ ...form, _subject: "Contact Form Inquiry - True Track Recovery" }),
      });
      if (res.ok) {
        setStatus("success");
        setForm({ name: "", email: "", message: "" });
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  const inputClass =
    "w-full px-4 py-3 bg-navy-800 border border-navy-700 rounded-xl text-white placeholder-navy-400 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent transition-all text-sm";

  return (
    <section id="contact" className="py-20 lg:py-28 bg-navy-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left */}
          <div>
            <span className="inline-block text-gold-400 font-semibold text-sm uppercase tracking-widest mb-3">
              Get in Touch
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl text-white mb-6">Contact Us</h2>
            <p className="text-blue-200 text-lg leading-relaxed mb-10">
              Have questions about our services or need assistance with your case? Our team is here to help. Reach out to us anytime.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gold-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-gold-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Email</h4>
                  <a href="mailto:support@truetrackrecovery.com" className="text-blue-200 hover:text-gold-400 transition-colors">
                    support@truetrackrecovery.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gold-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-gold-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Business Hours</h4>
                  <p className="text-blue-200">Monday – Friday: 8AM – 8PM EST</p>
                  <p className="text-blue-200">Saturday: 9AM – 5PM EST</p>
                  <p className="text-blue-200">Emergency cases: 24/7 Available</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gold-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-gold-400" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">International Cases</h4>
                  <p className="text-blue-200">We accept cases from victims worldwide. No matter your location, we can help.</p>
                </div>
              </div>
            </div>

            {/* Social */}
            <div className="mt-10">
              <h4 className="text-white font-semibold mb-4">Follow Us @truetrackrecovery</h4>
              <div className="flex gap-3">
                <a href="https://facebook.com/truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                  className="w-10 h-10 bg-navy-800 hover:bg-[#1877f2] text-blue-200 hover:text-white rounded-lg flex items-center justify-center transition-all">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </a>
                <a href="https://instagram.com/truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                  className="w-10 h-10 bg-navy-800 hover:bg-gradient-to-br hover:from-[#e1306c] hover:via-[#c13584] hover:to-[#833ab4] text-blue-200 hover:text-white rounded-lg flex items-center justify-center transition-all">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.849.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.849.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                  </svg>
                </a>
                <a href="https://tiktok.com/@truetrackrecovery" target="_blank" rel="noopener noreferrer" aria-label="TikTok"
                  className="w-10 h-10 bg-navy-800 hover:bg-black text-blue-200 hover:text-white rounded-lg flex items-center justify-center transition-all">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005.8 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1.84-.1z" />
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Right – Contact Form */}
          <div>
            <div className="bg-navy-900 rounded-2xl border border-navy-800 p-6 sm:p-8">
              <h3 className="text-white font-semibold text-xl mb-6">Send Us a Message</h3>

              {status === "success" ? (
                <div className="text-center py-8 animate-fade-in">
                  <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                  <p className="text-white font-semibold mb-2">Message Sent!</p>
                  <p className="text-blue-200 text-sm mb-4">We'll get back to you shortly.</p>
                  <button onClick={() => setStatus("idle")} className="text-gold-400 hover:text-gold-300 text-sm font-medium">
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="contact-name" className="block text-sm font-medium text-blue-200 mb-1.5">Your Name</label>
                    <input id="contact-name" type="text" required className={inputClass} placeholder="John Doe"
                      value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} />
                  </div>
                  <div>
                    <label htmlFor="contact-email" className="block text-sm font-medium text-blue-200 mb-1.5">Email Address</label>
                    <input id="contact-email" type="email" required className={inputClass} placeholder="john@example.com"
                      value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} />
                  </div>
                  <div>
                    <label htmlFor="contact-message" className="block text-sm font-medium text-blue-200 mb-1.5">Message</label>
                    <textarea id="contact-message" required rows={4} className={inputClass + " resize-none"} placeholder="How can we help you?"
                      value={form.message} onChange={(e) => setForm((p) => ({ ...p, message: e.target.value }))} />
                  </div>
                  {status === "error" && (
                    <div className="flex items-center gap-2 text-red-400 text-sm animate-fade-in">
                      <AlertCircle className="w-4 h-4" /> Something went wrong. Please try again.
                    </div>
                  )}
                  <button type="submit" disabled={status === "loading"}
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-gold-500 hover:bg-gold-400 disabled:bg-gold-300 text-navy-950 font-bold rounded-xl transition-all hover:shadow-lg hover:shadow-gold-500/25 disabled:cursor-not-allowed">
                    {status === "loading" ? (<><Loader2 className="w-5 h-5 animate-spin" /> Sending…</>) : (<><Send className="w-5 h-5" /> Send Message</>)}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
