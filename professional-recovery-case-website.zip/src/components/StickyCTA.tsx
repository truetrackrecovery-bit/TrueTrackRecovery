import { useState, useEffect } from "react";
import { ArrowRight } from "lucide-react";

export default function StickyCTA() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = () => {
    const el = document.querySelector("#case-review");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  if (!visible) return null;

  return (
    <button
      onClick={scrollTo}
      className="fixed bottom-6 right-6 z-40 group inline-flex items-center gap-2 px-5 py-3 bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-sm rounded-full shadow-xl shadow-[#1a5f9e]/20 transition-all hover:shadow-2xl hover:shadow-gold-500/40 animate-fade-in"
      aria-label="Start Free Case Review"
    >
      <span className="hidden sm:inline">Free Case Review</span>
      <ArrowRight className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
    </button>
  );
}
