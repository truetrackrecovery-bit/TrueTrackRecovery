import {
  Lock,
  Users,
  Eye,
  UserCheck,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import { useInView } from "../hooks/useInView";

const reasons = [
  {
    icon: Lock,
    title: "Confidential Reviews",
    desc: "Your case details are handled with the utmost discretion. All data is encrypted and accessible only to assigned analysts.",
  },
  {
    icon: Users,
    title: "Experienced Analysts",
    desc: "Our team comprises seasoned investigators with expertise in blockchain forensics, financial fraud, and asset recovery.",
  },
  {
    icon: Eye,
    title: "Transparent Process",
    desc: "We keep you informed at every stage. No hidden fees, no false promises — just honest, clear communication throughout.",
  },
  {
    icon: UserCheck,
    title: "Personalized Assessment",
    desc: "Every case is unique. We tailor our analysis and recommendations specifically to your circumstances and needs.",
  },
  {
    icon: ShieldCheck,
    title: "Secure Data Handling",
    desc: "Industry-standard security protocols protect your personal information and case documents at all times.",
  },
];

export default function WhyChooseUs() {
  const { ref, isInView } = useInView(0.1);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="why-us" className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left */}
          <div>
            <span className="inline-block text-gold-600 font-semibold text-sm uppercase tracking-widest mb-3">
              Why Choose Us
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-6">
              Trusted by Victims{" "}
              <span className="text-gold-500">Worldwide</span>
            </h2>
            <p className="text-navy-500 text-lg leading-relaxed mb-8">
              We understand the stress and urgency that comes with financial
              fraud. Our team is committed to providing professional,
              compassionate, and effective recovery assessments.
            </p>

            <button
              onClick={() => scrollTo("#case-review")}
              className="group inline-flex items-center gap-2 px-8 py-4 bg-navy-900 hover:bg-navy-800 text-white font-semibold rounded-xl transition-all hover:shadow-lg"
            >
              Get Your Free Assessment
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Right – reasons */}
          <div className="space-y-5">
            {reasons.map((r, i) => (
              <div
                key={r.title}
                className={`flex gap-4 p-5 rounded-xl border border-navy-100 hover:border-gold-300 hover:shadow-md transition-all duration-300 bg-navy-50/50 ${
                  isInView ? "animate-fade-in-up" : "opacity-0"
                } stagger-${i + 1}`}
              >
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
                  <r.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-navy-900 font-semibold text-base mb-1">
                    {r.title}
                  </h3>
                  <p className="text-navy-500 text-sm leading-relaxed">
                    {r.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
