import {
  Bitcoin,
  BarChart3,
  CandlestickChart,
  Globe,
  Fingerprint,
  Radar,
  Key,
  Building2,
  ArrowRight,
  Heart,
  Mail,
  Image,
  Network,
} from "lucide-react";
import { useInView } from "../hooks/useInView";

const services = [
  {
    icon: Bitcoin,
    title: "Cryptocurrency Fraud Recovery",
    desc: "Fake platforms, rug pulls, pig butchering scams, and fraudulent trading schemes. Blockchain analysis and tracing across exchanges and wallets.",
  },
  {
    icon: Heart,
    title: "Romance Scam Financial Loss",
    desc: "Long-term manipulation resulting in wire transfers, crypto sends, or gift card purchases to orchestrated identities. Compassionate, thorough case handling.",
  },
  {
    icon: BarChart3,
    title: "Investment Scam Recovery",
    desc: "Fake brokers, Ponzi schemes, or unlicensed investment advisors who misrepresented returns and refused withdrawals.",
  },
  {
    icon: CandlestickChart,
    title: "Forex Scam Recovery",
    desc: "Fraudulent forex trading platforms and unauthorized brokers. Tracing of fund flows through payment processors and offshore accounts.",
  },
  {
    icon: Building2,
    title: "Wire & Bank Transfer Fraud",
    desc: "Unauthorized transfers, business email compromise (BEC), or impersonation schemes resulting in misdirected payments. Rapid recall initiation.",
  },
  {
    icon: Globe,
    title: "Online Fraud Investigations",
    desc: "Comprehensive digital investigations into online scams, phishing attacks, identity fraud, and tech support impersonation.",
  },
  {
    icon: Key,
    title: "Account Access & Password Recovery",
    desc: "Locked out of your exchange, wallet, or online account? We help you navigate the process of recovering access to your own accounts and digital assets.",
  },
  {
    icon: Fingerprint,
    title: "Asset Tracing",
    desc: "Advanced tracing of hidden or laundered assets across traditional and digital financial systems, including cross-jurisdictional cases.",
  },
  {
    icon: Radar,
    title: "Digital Fund Tracking",
    desc: "Real-time monitoring and tracking of digital fund movements using cutting-edge OSINT and blockchain analytical tools.",
  },
  {
    icon: Mail,
    title: "Business Email Compromise",
    desc: "Investigation of email account takeovers leading to fraudulent wire transfers, with rapid-response account tracing and bank notification.",
  },
  {
    icon: Image,
    title: "NFT & Digital Asset Fraud",
    desc: "Fake NFT mints, marketplace impersonation, stolen digital collectibles, and fraudulent Web3 project investigations.",
  },
  {
    icon: Network,
    title: "Impersonation & Identity Fraud",
    desc: "Scammers posing as government agencies, banks, tech companies, or trusted entities. Full documentation and reporting support.",
  },
];

export default function Services() {
  const { ref, isInView } = useInView(0.05);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-navy-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-[#1a5f9e] font-semibold text-sm uppercase tracking-widest mb-3">
            Who We Help
          </span>
          <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl text-navy-900 mb-4">
            You Have a Case Worth Reviewing
          </h2>
          <p className="text-navy-500 text-lg">
            If any of these happened to you, our specialists can help. Fraud
            schemes are increasingly sophisticated — we handle complex cases
            that traditional channels fail to address.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
          {services.map((s, i) => (
            <div
              key={s.title}
              className={`group relative bg-white rounded-2xl p-6 border border-navy-100 hover:border-[#1a5f9e]/30 shadow-sm hover:shadow-xl transition-all duration-300 ${
                isInView ? "animate-fade-in-up" : "opacity-0"
              } stagger-${(i % 6) + 1}`}
            >
              <div className="w-12 h-12 bg-gradient-to-br from-[#1a5f9e] to-[#0f3460] rounded-xl flex items-center justify-center mb-4 group-hover:from-gold-500 group-hover:to-gold-600 transition-all duration-300">
                <s.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-heading text-lg text-navy-900 mb-2">
                {s.title}
              </h3>
              <p className="text-navy-500 leading-relaxed text-sm">
                {s.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Quick scam type tags */}
        <div className="bg-white rounded-2xl border border-navy-100 p-6 sm:p-8 mb-14">
          <h4 className="text-navy-900 font-semibold mb-4 text-center text-sm uppercase tracking-wider text-navy-500">
            Case Types We Handle
          </h4>
          <div className="flex flex-wrap gap-2 justify-center">
            {[
              "Cryptocurrency Fraud",
              "Romance Scam",
              "Investment Fraud",
              "Wire Transfer Fraud",
              "Forex Scam",
              "NFT Fraud",
              "Business Email Compromise",
              "Fake Broker Platforms",
              "Pig Butchering",
              "Tech Support Scam",
              "Real Estate Fraud",
              "Impersonation Fraud",
              "Account Recovery",
              "Password Recovery",
            ].map((tag) => (
              <span
                key={tag}
                className="px-3 py-1.5 bg-navy-50 text-navy-700 text-xs font-medium rounded-full border border-navy-200 hover:border-[#1a5f9e] hover:text-[#1a5f9e] transition-colors"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => scrollTo("#case-review")}
            className="group inline-flex items-center gap-2 px-8 py-4 bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold rounded-xl transition-all hover:shadow-lg hover:shadow-gold-500/25"
          >
            Submit Your Case — It's Free
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
