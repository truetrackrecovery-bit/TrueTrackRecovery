import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import TrustBar from "./components/TrustBar";
import HowItWorks from "./components/HowItWorks";
import Services from "./components/Services";
import WhyChooseUs from "./components/WhyChooseUs";
import CTABanner from "./components/CTABanner";
import CaseReviewForm from "./components/CaseReviewForm";
import Testimonials from "./components/Testimonials";
import Community from "./components/Community";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import StickyCTA from "./components/StickyCTA";

export default function App() {
  return (
    <div className="min-h-screen bg-white text-navy-900">
      <Navbar />
      <Hero />
      <TrustBar />
      <HowItWorks />
      <Services />
      <WhyChooseUs />
      <Testimonials />
      <CTABanner />
      <CaseReviewForm />
      <Community />
      <FAQ />
      <Contact />
      <Footer />
      <StickyCTA />
    </div>
  );
}
